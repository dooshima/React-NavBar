import React, { Component } from 'react';
import ToolBar from './Component/ToolBar';
import Bodys  from './Component/Bodys';

class App extends Component {

  render() {
   return (
    <div className="App">

        <ToolBar/>
        <Bodys/>
    </div>
    );
  }
}

export default App;
