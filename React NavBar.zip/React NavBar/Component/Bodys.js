import React from 'react';


const Bodys = props =>(
          <div className="">
            <h1>Hi my name is Anger Dooshima Lois!</h1>
          </div>

);

export default Bodys;
